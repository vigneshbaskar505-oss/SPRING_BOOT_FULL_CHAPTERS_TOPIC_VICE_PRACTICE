package in.sp.main.service;

import java.util.List;

import in.sp.main.model.Employee;

public interface EmployeeServiceInterface {

//	create
	Employee CreateEmployee(Employee emp);
	
//	get all - select
	List<Employee> getAllEmployees();
	
//	update
	Employee updateEmployee(Employee emp, int id);
	
//	get specific employee detail
	Employee getEmployeeById(int id);
	
//	delete
	void  deleteEmployee(int id);
	
	
	
	
	
}
