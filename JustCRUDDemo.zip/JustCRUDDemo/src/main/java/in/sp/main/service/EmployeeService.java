package in.sp.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.sp.main.model.Employee;
import in.sp.main.repo.EmployeeRepo;
//Service layer - business layer - logic 

@Service
public class EmployeeService implements EmployeeServiceInterface{
	
	
	@Autowired
	private EmployeeRepo repo;

	@Override
	public Employee CreateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return repo.save(emp);
//		to save given employee details
	}

	@Override
	public List<Employee> getAllEmployees() {
		//to show all employees list and details
		return repo.findAll();
	}

	@Override
	public Employee updateEmployee(Employee emp, int id) {
		// update employee details by id
		Employee updateinfo=repo.findById(id).orElse(null);
		updateinfo.setName(emp.getName());
		updateinfo.setDept(emp.getDept());
		return updateinfo;
	}

	@Override
	public Employee getEmployeeById(int id) {
//		get employee details by id
 		return repo.findById(id).orElse(null);
	}

	@Override
	public void deleteEmployee(int id) {
		// delete employee details by id
		
		repo.deleteById(id);
 		
	}

	
}
