package in.sp.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import in.sp.main.model.Employee;
import in.sp.main.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService serv;
	
	
//	1. post 
	
	@RequestMapping(value="/createEmp",method=RequestMethod.POST)
	public Employee createEmp(@RequestBody Employee emp) {
		return serv.CreateEmployee(emp);
	}
	
//	2. getall
	@RequestMapping(value="/showAll",method=RequestMethod.GET)
	public  List<Employee> showAllEmp(){
		return serv.getAllEmployees();
	}
	
	

	
//	3.update by id - put request
	@RequestMapping(value="/update/{id}",method=RequestMethod.PUT)
	public Employee updateById(@RequestBody Employee emp,@PathVariable int id) {
		return serv.updateEmployee(emp, id);
	}
	
//	4. delete by id - delete request
	
	@RequestMapping(value="/delete/{id}",method=RequestMethod.DELETE)
	public String deleteEmp(@PathVariable int id) {
		serv.deleteEmployee(id);
		return "Employee detail deleted successfully...";
		
	}
	
	
	
	
	
	
}
