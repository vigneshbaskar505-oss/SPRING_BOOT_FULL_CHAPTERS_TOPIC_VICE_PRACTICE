package in.sp.main.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import in.sp.main.model.Employee;

public interface EmployeeRepo  extends JpaRepository<Employee,Integer>{
//it acts as mediator between java code and sql through jdbc
	
//	repository - database layer
}
