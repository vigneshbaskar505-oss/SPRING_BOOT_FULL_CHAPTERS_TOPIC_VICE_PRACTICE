package in.main.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import in.main.model.Account;

public interface AccountRepository extends JpaRepository<Account, Integer> {
}
/*
JpaRepository — Provides built-in database operations.

Account — Specifies the entity type.

Integer — Specifies the primary key type.
 
 */
