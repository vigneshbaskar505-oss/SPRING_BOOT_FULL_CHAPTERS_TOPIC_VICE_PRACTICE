package in.main;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import in.main.model.Account;
import in.main.repo.AccountRepository;
import in.main.service.BankService;

@SpringBootApplication
public class SbClass12Application {

	public static void main(String[] args) {
		SpringApplication.run(SbClass12Application.class, args);
	}
	/*
	 Mini Project: Bank Money Transfer
1. Real-world scenario
Rahul wants to transfer ₹500 to Jenny.
-> ₹500 must be deducted from Rahul's account.
-> ₹500 must be added to Jenny's account.
-> If any operation fails, both changes should be rolled back.

2. What is @Transactional?

@Transactional helps ensure that related database operations succeed
 together or are rolled back together if a failure occurs.
 
	 */
//note: @Transactional manages both database updates as one transaction.
	
	 @Bean
	    CommandLineRunner setup(AccountRepository repository,
	                            BankService service) {
	        return args -> {

	            repository.save(new Account(1, "Rahul", 2000));
	            repository.save(new Account(2, "Jenny", 1000));

	            service.transferMoney();

	            System.out.println("Rahul Balance: "
	                    + repository.findById(1).orElseThrow().getBalance());

	            System.out.println("Jenny Balance: "
	                    + repository.findById(2).orElseThrow().getBalance());
	        };

}
}