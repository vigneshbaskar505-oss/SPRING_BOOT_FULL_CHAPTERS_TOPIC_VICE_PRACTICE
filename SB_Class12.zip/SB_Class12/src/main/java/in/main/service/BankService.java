package in.main.service;

import org.springframework.stereotype.Service;

import in.main.model.Account;
import in.main.repo.AccountRepository;
import jakarta.transaction.Transactional;

@Service
public class BankService {

	 private final AccountRepository repository;

	    public BankService(AccountRepository repository) {
	        this.repository = repository;
	    }

	    @Transactional
	    public void transferMoney() {

	        Account rahul = repository.findById(1).orElseThrow();
	        Account jenny = repository.findById(2).orElseThrow();

	       rahul.setBalance(rahul.getBalance() - 500);
	       jenny.setBalance(jenny.getBalance() + 500);

	        repository.save(rahul);
	        repository.save(jenny);

	        System.out.println("Money transferred successfully!");
	    }
	    
	    /*
	      steps:
 1. @Service — Marks the class as a service component.
 2. @Transactional — Runs the database operations within a transaction.
 3. findById() — Retrieves an account by ID.
 4. setBalance() — Updates the account balance.
 5. save() — Saves account changes.
 6. If a qualifying exception causes the transaction to roll back,
  both account updates are rolled back together.
	     */
	
}
