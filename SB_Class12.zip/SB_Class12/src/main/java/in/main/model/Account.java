package in.main.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Account {

	 @Id
	    private int id;

	    private String name;
	    private int balance;

	    public Account() {
	    }

	    public Account(int id, String name, int balance) {
	        this.id = id;
	        this.name = name;
	        this.balance = balance;
	    }

	    public int getId() {
	        return id;
	    }

	    public String getName() {
	        return name;
	    }

	    public int getBalance() {
	        return balance;
	    }

	    public void setBalance(int balance) {
	        this.balance = balance;
	    }
	    /*
	     concept:
	     
@Entity — Marks the class as a database entity.

@Id — Defines the primary key.

name — Stores the account holder's name.

balance — Stores the account balance.

Constructor — Initializes account details.

Getters and setter — Read and update account information.
	     */
}
