package in.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbClass4Application {

	public static void main(String[] args) {
		SpringApplication.run(SbClass4Application.class, args);
		
		/*
		 4: Dynamic Dropdown from Database Using Spring Boot
		 
          Mini Project: Employee Department Selection System

  Objective:
 Fetch department names from a database using Spring Boot 
 and display them dynamically in an HTML dropdown using JavaScript.
 
1. Understand the concept
Imagine a company has four departments:
->Java
->Python
-> AI/ML
-> Testing

If we write these names directly inside HTML, it is called a static dropdown.

If we store the names in a database and fetch them automatically 
through Spring Boot, it is called a "dynamic dropdown".



Final recap:

-> Entity: Represents the database record.
-> Repository: Retrieves records from the database.
-> Controller: Exposes the REST API.
-> JSON: Transfers data between backend and frontend.
-> JavaScript fetch(): Requests data from the API.
-> HTML <select>: Displays the dropdown options.
		 */
	}

}
