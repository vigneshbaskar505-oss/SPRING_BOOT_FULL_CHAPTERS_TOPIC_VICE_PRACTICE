package in.main.controller;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.main.model.Department;
import in.main.repository.DepartmentRepository;

@RestController
@RequestMapping("/api")
public class DepartmentController {

    private final DepartmentRepository repository;

    public DepartmentController(
            DepartmentRepository repository) {
        this.repository = repository;
    }

    @GetMapping("/departments")
    public List<Department> getDepartments() {
        return repository.findAll();
    }
    /*
     
@RestController      	    Returns data directly in the HTTP response.
@RequestMapping("/api") 	Defines the common URL prefix.
@GetMapping("/departments")	Handles requests to fetch departments.
     */
}