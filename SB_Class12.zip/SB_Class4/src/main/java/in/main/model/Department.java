package in.main.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "department")
public class Department {

	 @Id
	    private int id;

	    private String name;

	    public Department() {
	    }

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}
		
		/*
		 Explanation:
-> @Entity tells JPA that this class represents a database entity.
-> @Table(name = "department") specifies the database table name.
-> @Id identifies the primary key.
-> id stores the department ID.
-> name stores the department name.
		 */
	    
}
