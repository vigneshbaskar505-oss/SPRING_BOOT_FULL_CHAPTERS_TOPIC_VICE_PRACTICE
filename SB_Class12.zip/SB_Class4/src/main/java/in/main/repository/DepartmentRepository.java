package in.main.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import in.main.model.Department;

public interface DepartmentRepository
extends JpaRepository<Department, Integer> {
}
