INSERT INTO department (id, name)
VALUES (1, 'Java');

INSERT INTO department (id, name)
VALUES (2, 'Python');

INSERT INTO department (id, name)
VALUES (3, 'AI/ML');

INSERT INTO department (id, name)
VALUES (4, 'Testing');