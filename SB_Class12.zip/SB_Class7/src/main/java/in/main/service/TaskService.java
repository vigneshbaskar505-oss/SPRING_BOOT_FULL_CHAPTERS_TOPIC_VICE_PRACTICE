package in.main.service;

 
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

 
@Service
public class TaskService {

	@Scheduled(fixedRate = 5000)
    public void reminder() {
        System.out.println("Time to study Java!");
    }
}