package in.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
//@EnableScheduling enables automatic scheduled execution.
public class SbClass7Application {

	public static void main(String[] args) {
		SpringApplication.run(SbClass7Application.class, args);
	}
	
	/*
	  Scheduling
	  7. Smart Task Scheduler Dashboard
	 * 
	 * Real-world use:
	 *  Automatic reminders, 
	 * periodic checks,
	 *  and scheduled report generation.
	 */

}
