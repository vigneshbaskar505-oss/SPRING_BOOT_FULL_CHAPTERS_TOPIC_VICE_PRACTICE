package in.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbClass9Application {

	public static void main(String[] args) {
		SpringApplication.run(SbClass9Application.class, args);
	}

//	Validation using Hibernate validator
	/* Postman testing with json
	 
	 Test 1: Valid input
	 {
     "name": "Arun",
     "age": 22
     }
     
     Test 2: Invalid age
     {
     "name": "Arun",
      "age": 15
    }
    
    Test 3: Empty name
    {
   "name": "",
   "age": 22
     }
	 */
}
