package in.main.controller;

import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import in.main.model.Student;
import jakarta.validation.Valid;

@RestController
public class StudentController {

	 @PostMapping("/student")
	    public String registerStudent(@Valid @RequestBody Student student) {
	        return "Student registered successfully!";
	    }
	 /*
	  @RestController — Handles HTTP requests and returns responses.

     @PostMapping("/student") — Accepts POST requests at /student.

    @RequestBody — Converts incoming JSON into a Student object.

    @Valid — Triggers the validation rules defined in Student.java.

   registerStudent() — Processes the student registration request.
	  */
//	 
	 @ExceptionHandler(MethodArgumentNotValidException.class)
	 public String handleValidationError(MethodArgumentNotValidException ex) {
 	 
		 return ex.getBindingResult().getFieldError().getDefaultMessage();
	 }
}
