package in.main.model;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

public class Student {
	
	/*
	  concept:
	  @NotBlank — Prevents empty or whitespace-only names.

      @Min(18) — Sets the minimum age to 18.

      @Max(60) — Sets the maximum age to 60.

     message — Defines the error message shown when validation fails.

     Getters and setters — Read and update student details.
	 */

	@NotBlank(message = "Name cannot be empty")
    private String name;

    @Min(value = 18, message = "Age must be at least 18")
    @Max(value = 60, message = "Age must not exceed 60")
    private int age;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
