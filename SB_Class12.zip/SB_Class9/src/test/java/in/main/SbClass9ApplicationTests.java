package in.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbClass9ApplicationTests {

	@Test
	void contextLoads() {
	}

}
