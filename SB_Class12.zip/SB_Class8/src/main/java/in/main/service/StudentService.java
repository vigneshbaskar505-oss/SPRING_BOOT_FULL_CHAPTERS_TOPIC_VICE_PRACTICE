package in.main.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class StudentService {

	private static final Logger log =LoggerFactory.getLogger(StudentService.class);

    public void showStudent() {

        log.info("Student details opened");
        log.warn("Student attendance is low");
        log.error("Unable to load student details");
    }
}
