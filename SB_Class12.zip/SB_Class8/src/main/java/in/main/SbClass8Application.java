package in.main;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import in.main.service.StudentService;

@SpringBootApplication
public class SbClass8Application {

	public static void main(String[] args) {
		SpringApplication.run(SbClass8Application.class, args);
	}
	
	 @Bean
	    CommandLineRunner run(StudentService service) {
	      return args -> service.showStudent();
	    }

/* 
       8.Logging in Spring Boot
 
 Mini Project: Student Activity Logger
 
    logger —  helps to view log messages display  .
    log.info() — normal activity.
    log.warn() — warning.
    log.error() — error information.
        
    CommandLineRunner – Executes code when the application starts.

   service.showStudent() – Calls the student service method.
 */
}
