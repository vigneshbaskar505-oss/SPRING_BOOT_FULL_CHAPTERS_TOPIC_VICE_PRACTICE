package in.main.service;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class StudentService {

	 @Cacheable("students")
	    public String getStudent() {

	        System.out.println("Fetching student details...");

	        return "Student Name: Anabella";
	    }
	 
	 /*
	  Concept:
	  @Service — Marks the class as a Spring service.

      @Cacheable("students") — Stores the method result in a cache named students.

      System.out.println() — Helps us observe when the method executes.

      return — Returns the student details.
	  */
}
