package in.main;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;

import in.main.service.StudentService;

@SpringBootApplication
@EnableCaching
//@EnableCaching — Enables caching support.
public class SbClass11Application {

	public static void main(String[] args) {
		SpringApplication.run(SbClass11Application.class, args);
	}

	/*
	      Mini Project: Student Details Cache
	      
Real-World Example: 
When student details are requested repeatedly,
 caching stores the previously fetched result and returns it 
 faster instead of retrieving it from the database every time.
 
1. What is Caching?
-> First Request: Retrieve student details.
-> Store in Cache: Temporarily store the retrieved result.
-> Next Request: Reuse the cached result for a faster response.

2. Important Annotations

   Annotation            	Purpose
1.@EnableCaching	  Enables caching in the application.
2.@Cacheable	      Stores and reuses method results from the cache.
3.@CacheEvict	      Removes an entry from the cache.
	 */
	
	@Bean
    public CacheManager cacheManager() {
        return new ConcurrentMapCacheManager("students");
    }
	
	@Bean
	CommandLineRunner testCache(StudentService service) {
	    return args -> {
	        System.out.println("First Call:");
	        System.out.println(service.getStudent());

	        System.out.println("Second Call:");
	        System.out.println(service.getStudent());
	    };
	}
	
/*
 CacheManager — Manages the application's cache.

ConcurrentMapCacheManager — Provides a simple in-memory cache.

"students" — Creates the cache used by @Cacheable("students").

@Bean — Registers the cache manager with Spring.

 */
}
