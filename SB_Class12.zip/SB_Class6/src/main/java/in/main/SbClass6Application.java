package in.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbClass6Application {

	public static void main(String[] args) {
		SpringApplication.run(SbClass6Application.class, args);
		
		/*
		 6. How to Make a PUT Request in Spring Boot
		 
       Mini project: Update Employee Details

     Goal: Update an existing employee's details using an HTTP PUT request.
     
1. Understand PUT

Imagine an employee has changed their department from Java to AI/ML.

Instead of creating another employee, we send an update request for the existing employee.
-> GET — retrieve information.
-> POST — create or submit information.
-> PUT — update an existing resource.
-> DELETE — remove a resource.

Important Annotations:

Annotation	              Purpose
1. @PutMapping	     Maps HTTP PUT requests to a Java method.
2. @PathVariable	Reads the employee ID from the URL.
3. @RequestBody	     Reads the updated employee details from JSON.
4. ResponseEntity	Lets us control the HTTP response and status code.
		 
		 */
	}

}
