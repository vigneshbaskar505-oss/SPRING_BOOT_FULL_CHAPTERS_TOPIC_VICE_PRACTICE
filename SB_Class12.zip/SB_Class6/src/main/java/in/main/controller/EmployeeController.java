package in.main.controller;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import in.main.model.Employee;

@RestController
public class EmployeeController {

	 private final Map<Integer, Employee> employees =
	            new ConcurrentHashMap<>();

	    public EmployeeController() {
	        Employee employee = new Employee();
	        employee.setId(101);
	        employee.setName("Arun");
	        employee.setDepartment("Java");

	        employees.put(101, employee);
	    }

	    @PutMapping("/employees/{id}")
	    public ResponseEntity<?> updateEmployee(
	            @PathVariable int id,
	            @RequestBody Employee updatedEmployee) {

	        if (!employees.containsKey(id)) {
	            return ResponseEntity.notFound().build();
	        }

	        updatedEmployee.setId(id);
	        employees.put(id, updatedEmployee);

	        return ResponseEntity.ok(updatedEmployee);
	    }

	    @GetMapping("/employees/{id}")
	    public ResponseEntity<?> getEmployee(
	            @PathVariable int id) {

	        Employee employee = employees.get(id);

	        if (employee == null) {
	            return ResponseEntity.notFound().build();
	        }

	        return ResponseEntity.ok(employee);
	    }
	    
	    /*
	     Test using Postman
First, retrieve the existing employee:
 GET 
{
  "id": 101,
  "name": "Arun",
  "department": "Java"
}


PUT
{
  "name": "Arun Kumar",
  "department": "AI/ML"
}
	     */
}
