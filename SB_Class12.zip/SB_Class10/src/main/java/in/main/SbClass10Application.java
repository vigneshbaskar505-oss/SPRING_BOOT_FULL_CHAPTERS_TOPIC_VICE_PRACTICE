package in.main;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import in.main.dto.StudentDTO;
import in.main.service.StudentService;

@SpringBootApplication
public class SbClass10Application {

	public static void main(String[] args) {
		SpringApplication.run(SbClass10Application.class, args);
	}
	
	/*
	  DTO + ModelMapper in Spring Boot  

         Mini Project: Student Data Transfer
         
         
      
     Real-world use:  
     Share required info through API response , without showing all sensitive info

Process flow:

    1. CommandLineRunner — Executes code when the application starts.

    2. service.getStudent() — Retrieves the DTO object.

    3.dto.getName() — Reads the student's name.

    4.dto.getEmail() — Reads the student's email.

   => DTO helps transfer only the required fields.

   => ModelMapper automatically copies matching fields.
     */
	 @Bean
	    CommandLineRunner run(StudentService service) {
	        return args -> {
	            StudentDTO dto = service.getStudent();

	            System.out.println("Student Name: " + dto.getName());
	            System.out.println("Student Email: " + dto.getEmail());
	            
 	            
	        };
	    }

}
