package in.main.dto;

public class StudentDTO {

	    private String name;
	    private String email;
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
	    
	    /*
	     *concept:
	     Student — Stores the complete student details.

         StudentDTO — Contains only the data we want to transfer.

         age is excluded from the DTO, so it won't appear in the DTO response.
	     */

}
