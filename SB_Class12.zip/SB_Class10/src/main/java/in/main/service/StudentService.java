package in.main.service;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import in.main.dto.StudentDTO;
import in.main.model.Student;

@Service
public class StudentService {

	public StudentDTO getStudent() {

        Student student = new Student();

        student.setName("Arun");
        student.setAge(22);
        student.setEmail("arun@gmail.com");

        ModelMapper mapper = new ModelMapper();

        StudentDTO dto = mapper.map(student, StudentDTO.class);

        return dto;
        /*
          concepts:
         1. new Student() — Creates a student object.

         2. setName(), setAge(), setEmail() — Assign student details.

         3.new ModelMapper() — Creates a ModelMapper object.

         4.mapper.map() — Copies matching field values automatically.

         5.StudentDTO.class — Specifies the destination object type.

         6.return dto — Returns the DTO object.
         */
    }
}
