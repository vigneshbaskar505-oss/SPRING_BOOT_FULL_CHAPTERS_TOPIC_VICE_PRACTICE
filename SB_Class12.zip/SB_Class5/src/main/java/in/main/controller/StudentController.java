package in.main.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import in.main.model.Student;

@RestController
public class StudentController {

	@PostMapping("/students")
    public String registerStudent(
            @RequestBody Student student) {

        return "Student registered successfully! "
                + "ID: " + student.getId()
                + ", Name: " + student.getName()
                + ", Course: " + student.getCourse();
    }
	
	/* Test using Postman
	 {
  "id": 101,
  "name": "Anu",
  "course": "Java"
} 
	 */
	 

}
