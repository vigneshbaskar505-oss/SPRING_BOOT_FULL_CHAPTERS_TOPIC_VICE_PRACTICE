package in.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbClass5Application {

	public static void main(String[] args) {
		SpringApplication.run(SbClass5Application.class, args);
		
		/*
		 5. How to Get the Body of a Request in Spring Boot
		 
        Mini project: Student Registration API

        Goal: Accept student details sent by a client in JSON format.
        
        
   1. Understand the concept
        
Suppose a student registration form submits these details:

{

  "id": 101,
  "name": "Anu",
  "course": "Java"
}


Spring Boot needs to read this incoming data and
 make it available to the Java method.

That is the purpose of @RequestBody.


Key annotations:
-> @PostMapping — handles a POST request.
-> @RequestBody — reads the HTTP request body and converts it into a Java object.
-> @RestController — returns data or text directly as the HTTP response.
Spring uses HTTP message converters to handle JSON conversion when
 the necessary JSON support is available. 




Practice task: 
Add an email field to Student, send it in the JSON request,
 and display it in the response.


		 */
	}

}
