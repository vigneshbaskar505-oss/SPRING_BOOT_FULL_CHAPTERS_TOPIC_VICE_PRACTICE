package in.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import in.main.model.Employee;
import in.main.service.EmployeeService;

@RestController
public class EmployeeController {

	 @Autowired
	    private EmployeeService employeeService;

	    @GetMapping("/employee")
	    public Employee getEmployee() {
	        return employeeService.getEmployee();
	    }
	    
	    
	    /*
	     Expected JSON response:(write it in postman)
         {
            "id": 101,
            "name": "Arun"
           }
	     */
	     
}
