package in.main.repository;

public class EmployeeRepository {

}
