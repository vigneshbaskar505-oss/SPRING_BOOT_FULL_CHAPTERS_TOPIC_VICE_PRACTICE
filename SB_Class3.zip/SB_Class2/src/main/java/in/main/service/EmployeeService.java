package in.main.service;

import org.springframework.stereotype.Service;

import in.main.model.Employee;

@Service
public class EmployeeService {

    public Employee getEmployee() {
        return new Employee(200, "Francis");
    }
}

