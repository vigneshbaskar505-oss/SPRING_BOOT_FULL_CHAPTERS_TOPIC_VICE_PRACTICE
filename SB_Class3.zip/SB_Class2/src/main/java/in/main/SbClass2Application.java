package in.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbClass2Application {

	public static void main(String[] args) {
		SpringApplication.run(SbClass2Application.class, args);
	/*
	 2. Best Practices for Structuring a Spring Boot
	  Application
	  
    Mini project: Employee Information API


    Goal: Organize code so that a project remains 
              understandable when it grows.
              
              
       1. Employee represents the employee data.

       2.EmployeeService contains the logic to obtain employee information.

       3. EmployeeController receives the request and returns the result.

       4. @Service tells Spring that the class is a service component.

       5. @Autowired asks Spring to inject the required service object
       
       
       
       Practice task:
       
    Create Product, ProductService, and ProductController classes.
    Return a product with ID 1 and name Laptop at /product.
	 */
		
		
	
	
	}

}
