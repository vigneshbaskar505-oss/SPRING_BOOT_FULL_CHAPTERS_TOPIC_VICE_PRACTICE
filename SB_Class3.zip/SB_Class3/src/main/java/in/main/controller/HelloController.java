package in.main.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

	  @GetMapping("/hello")
	    public String sayHello(
	            @RequestParam(defaultValue = "Student") String name) {

	        return "Hello, " + name
	                + "! Welcome to Spring Boot.";
	    }
//	  output:http://localhost:8080/hello?name=Anusree
	  
//	  If visit /hello without providing a name, the response will
//	  use the default name Student.
	  
	  /*
	   @GetMapping("/hello")  -->	Handles GET requests to /hello.
	   
       @RequestParam	      --> Reads a value from the URL query string.
       
       defaultValue = "Student" -->	Supplies a value when the parameter is absent.
       
         return	               --> Sends the greeting as the response body.
	   */
	   
}
