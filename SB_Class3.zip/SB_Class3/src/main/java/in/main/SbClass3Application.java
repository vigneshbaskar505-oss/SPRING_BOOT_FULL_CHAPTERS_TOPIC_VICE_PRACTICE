package in.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbClass3Application {

	public static void main(String[] args) {
		SpringApplication.run(SbClass3Application.class, args);
		
		/*
		 3. Spring Boot — Hello World Example
		 
        Mini project: Personalized Greeting API
        
        Goal: Receive a name from the URL and display
         a personalized greeting
         
         For example:
      -> URL: http://localhost:8080/hello?name=Jayasree
      -> Output: Hello, Jayasree! Welcome to Spring Boot.
      
      
      
      
      Real-world use:
       Personalized greetings,
       search filters,
       product searches, 
       and simple read-only API endpoints.

This example follows the basic REST service approach documented by Spring. 


Create /welcome?course=Java and return:

Welcome to the Java course!

Hint: Replace the name request parameter with course.
		 */
	}

}
