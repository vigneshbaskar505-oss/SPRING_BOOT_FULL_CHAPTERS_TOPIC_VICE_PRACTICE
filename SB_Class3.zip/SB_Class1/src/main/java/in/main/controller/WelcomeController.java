package in.main.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WelcomeController {

	@GetMapping("/welcome")
    public String welcome() {
        return "Welcome to Spring Boot!";
    }
}

/*
 
 Annotation	                   Simple meaning
 
1.@SpringBootApplication =	Marks the main application class and enables
                             Spring Boot configuration.
                             
2.@RestController	     =   Handles web requests and returns response data.

3.@GetMapping("/welcome")=	Connects a GET request to the /welcome URL

 */


/*
 Practice tasks:
 
-> Change the output to Hello, Students!.

->Create another URL, /course, that returns Java Spring Boot Course.

-> Create /trainer that returns Welcome to the Training Institute. 
 */



