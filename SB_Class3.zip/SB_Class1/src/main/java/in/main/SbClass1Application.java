package in.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbClass1Application {

	public static void main(String[] args) {
		SpringApplication.run(SbClass1Application.class, args);
	
	
	/*
	1. How to Create a Basic Spring Boot Application?
    Mini project: Welcome Application
    
   Goal: Create a Java application that runs a
    web server and displays a welcome message 
    in the browser.  
	 */
	
	}

}


