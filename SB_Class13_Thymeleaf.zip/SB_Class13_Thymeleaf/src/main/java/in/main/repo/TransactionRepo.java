package in.main.repo;
import org.springframework.data.jpa.repository.JpaRepository;
import in.main.model.*;
public interface TransactionRepo extends JpaRepository<BankTransaction,Long> 
{

}
