package in.main.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import in.main.model.Account;

public interface AccountRepo extends JpaRepository<Account,Long>
{

}
