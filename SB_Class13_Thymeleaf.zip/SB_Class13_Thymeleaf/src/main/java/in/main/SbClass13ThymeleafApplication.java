package in.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbClass13ThymeleafApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbClass13ThymeleafApplication.class, args);
	}

}
