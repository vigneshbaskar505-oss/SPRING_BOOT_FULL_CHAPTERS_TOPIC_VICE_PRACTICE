package in.main.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
@Entity
@Table
public class BankTransaction {

	
//	id,amt,transaction date , from Account and to account (using Account class)
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	
	private BigDecimal amount;
	
	private LocalDateTime transactionDate;
	
	@ManyToOne
	@JoinColumn(name = "from_acc_id", referencedColumnName = "id")
	private Account fromaccount;

	@ManyToOne
	@JoinColumn(name = "to_acc_id", referencedColumnName = "id")
	private Account toaccount;
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public LocalDateTime getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(LocalDateTime transactionDate) {
		this.transactionDate = transactionDate;
	}

	public Account getFromaccount() {
		return fromaccount;
	}

	public void setFromaccount(Account fromaccount) {
		this.fromaccount = fromaccount;
	}

	public Account getToaccount() {
		return toaccount;
	}

	public void setToaccount(Account toaccount) {
		this.toaccount = toaccount;
	}

	public BankTransaction(BigDecimal amount, LocalDateTime transactionDate, Account fromaccount, Account toaccount) {
 		this.amount = amount;
		this.transactionDate = transactionDate;
		this.fromaccount = fromaccount;
		this.toaccount = toaccount;
	}

	public BankTransaction() {
	}
	
//	@ManyToOne means multiple transactions can belong to the 
//	same sender or receiver account.
	
	
	
	
	
	
	
}
