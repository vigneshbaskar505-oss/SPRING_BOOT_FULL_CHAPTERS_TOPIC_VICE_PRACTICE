package in.main.model;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "accounts")
public class Account {

//	id,acc num,acc holder and balance
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	
	@Column(unique=true,nullable=false)
	private long acc_num;
	
	private String acc_name;
	
	@Column(nullable=false,precision=12,scale=2)
	private BigDecimal balance;

//	BigDecimal for money rather than double, because it provides more 
//	reliable decimal arithmetic for financial values.
	
	
	public Account(long acc_num, String acc_name, BigDecimal balance) {
 		this.acc_num = acc_num;
		this.acc_name = acc_name;
		this.balance = balance;
	}
	
	public Account() {
		
	}
	
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getAcc_num() {
		return acc_num;
	}

	public void setAcc_num(long acc_num) {
		this.acc_num = acc_num;
	}

	public String getAcc_name() {
		return acc_name;
	}

	public void setAcc_name(String acc_name) {
		this.acc_name = acc_name;
	}

	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	
}
