package in.main.service;

import java.math.BigDecimal;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import in.main.model.Account;
import in.main.model.BankTransaction;
import in.main.repo.AccountRepo;
import in.main.repo.TransactionRepo;
 
@Service
public class BankService {

	private final AccountRepo act;
	private final TransactionRepo tran;
	public BankService(AccountRepo act, TransactionRepo tran) {
 		this.act = act;
		this.tran = tran;
	}
	
//	main logic
	@Transactional
	public void transferMoney(Long fromId,Long toId,BigDecimal amt,boolean simulateFailure) {
//	1.validate amt
	if(amt==null || amt.compareTo(BigDecimal.ZERO)<=0) {
		throw new IllegalArgumentException("Enter a valid amount");
	}
	
//	2.validate account
	if(fromId.equals(toId)) {
		throw new IllegalArgumentException("Sender and Receiver id cannot be same");
		
	}
	
//	3.find sender account
	Account sender=act.findById(fromId).orElseThrow(()->new IllegalArgumentException("Sender account not found..."));
	
//	4.find receiver account
	Account rcvr=act.findById(toId).orElseThrow(()->new IllegalArgumentException("Receiver account not found..."));

	
//	5.check available balance
	if(sender.getBalance().compareTo(amt)<0) {
		throw new IllegalArgumentException("Insufficient Balance..");
	}
	
//	6. Deduct money from sender
	sender.setBalance(sender.getBalance().subtract(amt));
	act.save(sender);
	
//	7. add money to rcvr
	
	rcvr.setBalance(rcvr.getBalance().add(amt));
	act.save(rcvr);
	
//	8. Save transaction history
	BankTransaction bt = new BankTransaction(amt,java.time.LocalDateTime.now(),sender,rcvr);
	tran.save(bt);
	
//	9. Simulate failure for rollback demo
	if(simulateFailure) {
		
		throw new RuntimeException("Simulation Error!! Transaction rolled back...");
	}
	
	
	
	
	}
	
	
}
