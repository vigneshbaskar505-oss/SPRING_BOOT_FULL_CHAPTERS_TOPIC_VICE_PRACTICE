package in.main.controller;

import java.math.BigDecimal;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import in.main.repo.AccountRepo;
import in.main.repo.TransactionRepo;
import in.main.service.BankService;

@Controller
public class BankController {

//	The controller receives requests from the browser and
//	connects the frontend with the service class.
//	
	
	private final AccountRepo acc;
	private final TransactionRepo tran;
	private final BankService bk;
	public BankController(AccountRepo acc, TransactionRepo tran, BankService bk) {
		this.acc = acc;
		this.tran = tran;
		this.bk = bk;
	}
	
	
//	1. Dashboard page
	@GetMapping("/")
	public String dashboard(Model model) {
		
		model.addAttribute("accounts",acc.findAll());
		return "dashboard";
	}
	
//	2. Display Transfer page
	
	@GetMapping("/transfer")
	public String transferpage(Model model) {
		
		model.addAttribute("accounts",acc.findAll());
		return "transfer";
	}
	
//	3.process money
	@PostMapping("/transfer")
	public String transferMoney(
	        @RequestParam("fromAccountId") Long fromId,
	        @RequestParam("toAccountId") Long toId,
	        @RequestParam("amount") BigDecimal amt,
	        @RequestParam(defaultValue = "false") boolean simulatefailure,
	        RedirectAttributes redirectattr) {
		
		
		try {
			bk.transferMoney(fromId, toId, amt, simulatefailure);
			
			redirectattr.addFlashAttribute("Success","Money transaction successfully...");
			
		}
		catch(IllegalArgumentException | IllegalStateException e) {
			redirectattr.addAttribute("error", e.getMessage());
			
		}
		catch(RuntimeException e) {
			redirectattr.addAttribute("error", e.getMessage());
			
		}
	
		return "redirect:/";
//		note:very important in sb app
//		After processing the transfer, the browser returns to the dashboard/
//		and displays the success or error message.
		
	}
	
	
	
	
//	4. history page
	@GetMapping("/history")
	public String historypage(Model model) {

	    model.addAttribute("transactions", tran.findAll());

	    return "history";
	}
	
	
	
	
	
	
	
}
